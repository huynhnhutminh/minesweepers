﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1_Minesweeper
{
    public partial class Form1 : Form
    {
        int Time = 0;
        int timebxh=0;
        int minebxh=0;
        public Form1()
        {
            InitializeComponent();
            this.Text = Application.ProductName + " " + Application.ProductVersion;
        }
        private void NewGame()
        {
            minesBoardUI1.NewGame();
            RenewForm();
        }
        private void NewGame(int rows, int cols, int mines)
        {
            minesBoardUI1.NewGame(rows, cols, mines);
            RenewForm();
        }
        private void RenewForm()
        {
            button1.BackgroundImage = Properties.Resources.face1;
            this.Height = minesBoardUI1.Height + 100;
            this.Width = minesBoardUI1.Width + 20;
            lblTime.Text = "Timer";
            Time = 0;
            UpdateMines();
        }
        void UpdateMines()
        {
            lblMines.Text = String.Format("{0:000}", minesBoardUI1.MinesCount - minesBoardUI1.FlagsCount);
            if (minesBoardUI1.RemainCellsCount == minesBoardUI1.MinesCount)
                button1.BackgroundImage = Properties.Resources.face4;
        }
        void CheckMenuItem(ToolStripMenuItem menuItem)
        {
            foreach (var item in gameToolStripMenuItem1.DropDownItems)
            {
                ToolStripMenuItem mi = item as ToolStripMenuItem;
                if (mi != null)
                    mi.Checked = false;
            }
            menuItem.Checked = true;
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGame();
        }
        private void contentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("huynhnhutminhproject1");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewGame();
        }

       
        private void beginnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGame(9, 9, 10);
            CheckMenuItem(sender as ToolStripMenuItem);
        }

        private void intermediateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGame(16, 16, 40);
            CheckMenuItem(sender as ToolStripMenuItem);
        }

        private void expertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGame(25, 40, 200);
            CheckMenuItem(sender as ToolStripMenuItem);
        }

        private void customToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomForm frm = new CustomForm(minesBoardUI1.Rows, minesBoardUI1.Cols, minesBoardUI1.MinesCount);

            if (frm.ShowDialog() == DialogResult.OK)
            {
                NewGame(frm.Rows, frm.Cols, frm.Mines);
            }
            CheckMenuItem(sender as ToolStripMenuItem);

        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void minesBoard1_MinesExplode(object sender, EventArgs e)
        {
            button1.BackgroundImage = Properties.Resources.face3;
            Timer_1.Stop();
        }

        private void minesBoardUI1_CellClick(object sender, EventArgs e)
        {
            UpdateMines();
            Timer_1.Start();
        }

        private void minesBoardUI1_MinesExplode(object sender, EventArgs e)
        {
            button1.BackgroundImage = Properties.Resources.face1;
            Timer_1.Stop();

        }
       public struct BXH
        {
          //  public int stt;
           // public string name;
            public int mine;
            public int time;
        }
       
public void writeBXH(int mine,int timeBXH)
        {
            BXH[] b = new BXH[1];
            for(int i = 0; i < 1; i++)
            {
               // b[i].stt = i+1;
                //b[i].name = name;
                b[i].mine = mine;
                b[i].time = timeBXH;
            }
            using (System.IO.StreamWriter file =
                     new System.IO.StreamWriter(@"E:\HCMUTE\Project One\bxh.txt"))
            {
                foreach (BXH line in b)
                {
                    //file.Write(line.stt);
                   // file.Write(line.name);
                    file.WriteLine(line.mine);
                    file.WriteLine(line.time);
                }
            }

        }
public void readFile()
        {
            string[] lines;
            var list = new List<string>();
            var fileStream = new FileStream(@"E:\HCMUTE\Project One\bxh.txt", FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    list.Add(line);
                }
            }
            lines = list.ToArray();
            minebxh = Int32.Parse(lines[0]);
            timebxh = Int32.Parse(lines[1]);
        }
        private void Timer1_Tick_1(object sender, EventArgs e)
        {
            Time++;
            readFile();
            lblTime.Text = Time + "S";          
            if (minesBoardUI1.RemainCellsCount == minesBoardUI1.MinesCount)
            {
                Timer_1.Stop();
                if(minesBoardUI1.MinesCount >= minebxh && Time < timebxh) { 
                MessageBox.Show("Chúc mừng bạn đã chiến thắng và lập kỉ lục mới ! Với số mìn : "+ minesBoardUI1.MinesCount + " thời gian "+ Time+"s");
                writeBXH(minesBoardUI1.MinesCount,Time);
                }else { 
                MessageBox.Show("Chúc mừng bạn đã chiến thắng!");
                }
            }
            if (minesBoardUI1.IsLost)
            {
                Timer_1.Stop();
               // MessageBox.Show("Chúc mừng bạn đã chiến thắng! mine " + minebxh + " " + timebxh);
            }
        }
    }
}
